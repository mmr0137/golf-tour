from django.apps import AppConfig


class TournamentConfig(AppConfig):
    name = 'tournament'
