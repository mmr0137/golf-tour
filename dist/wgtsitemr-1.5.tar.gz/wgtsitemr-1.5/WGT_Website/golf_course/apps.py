from django.apps import AppConfig


class GolfCourseConfig(AppConfig):
    name = 'golf_course'
