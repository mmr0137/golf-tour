README.txt
------------------
This package contains the code and database for the Wake Golf Tour project from the Wake Tech CSC122 - Python Applications class.
------------------
